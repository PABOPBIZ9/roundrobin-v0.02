# Gold on 1 · Post-Cup Special

Slug: 

## 01 · desk-host-a

Gold on One — Post-Cup Special. Confetti still on the Neon Reef ice. Miami Mighty Geckz are the first-ever PuckGold Champions.

## 02 · kai-sandoval

Small creature. Massive heart. We never stopped believing — even when it was five-one on aggregate.

## 03 · desk-host-b

Kai — walk us through overtime. Rebound springs free…

## 04 · kai-sandoval

I just saw ice. One-on-one. Triple-deke. Top shelf. Then the village — booth, fans, Aura votes — lifted us.

## 05 · nathaniel-cross

We played five-and-a-half perfect periods. It wasn't enough. Empire doesn't fold — we reload for Expansion.

## 06 · wyatt-combs

Zero in the standings. Everything in the fans' hearts. Conductor's Crest means we played the right way.

## 07 · marcus-doyle

We made history in overtime Game One — then Miami made more. Capital hockey tip-off again this weekend.

## 08 · jack-jet-morrison

From Terminal Arena to golden confetti — Season One is lore. Season Two starts now. Road to PuckGold one-twenty-eight.

## 09 · desk-host-a

Farm the Fan Zone. Claim the O-G Pass for five-X. And we'll see you under the Expansion clock.
