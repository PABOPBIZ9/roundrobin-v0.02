# Voice Roster Showcase · Season One

Slug: 

## 01 · pucky

Heeey bestie — I'm Pucky! Welcome to the PuckGold voice booth… heh heh… don't blink.

## 02 · jack-jet-morrison

Jack Jet Morrison — play-by-play from Neon Reef. Live calls, overtime chaos, Cup nights.

## 03 · veteran-color

Veteran color. I break down the bench, the structure, and why miracles still matter.

## 04 · coach-chippy

Coach Chippy in the house — culture, chirps, and absolute nuclear rink energy!

## 05 · arena-pa

Your Arena P A. Deep ice. Long vowels. Goal announcements with gravitas.

## 06 · desk-host-a

Lexi Gold — podcast desk. Warm studio energy for Backstory and Gold on One.

## 07 · desk-host-b

Riley Vance — co-host. Fantasy angles, Expansion teases, and cold hard tape.

## 08 · sideline-nova

Nova Reyes, rink-side. Between the benches, between the whistles — I'll get you the quote.

## 09 · studio-mira

Mira Chen in studio. Weak-side seams, matchup edges, and Expansion pool reads.

## 10 · kai-sandoval

Kai Sandoval, Miami. Small creature. Massive heart. We never stopped believing.

## 11 · nathaniel-cross

Nathaniel Cross, McLean. Empire doesn't fold — we reload for Expansion.

## 12 · marcus-doyle

Marcus Doyle, Washington. Capital hockey tip-off — history, then the next shift.

## 13 · wyatt-combs

Wyatt Combs, Chattanooga. Zero in the standings. Everything in the fans' hearts.

## 14 · milo-reyes

Milo Reyes — when the Reef shook in the third, I knew we had them.

## 15 · emmett-solis

Emmett Solis in net. See the puck. Stop the puck. Let the boys cook.

## 16 · pucky

That's the village voice pack! Farm Listen XP, grab the thirty-six dollar O-G Offer for five-X… heh heh… see you under the clock!
