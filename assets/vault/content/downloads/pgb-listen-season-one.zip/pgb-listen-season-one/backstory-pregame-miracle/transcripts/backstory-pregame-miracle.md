# PuckGold Backstory · Pre-Game Special

Slug: 

## 01 · desk-host-a

Welcome to PuckGold Backstory — Pre-Game Special. Tonight we rewind the Founding Four… and preview Expansion Weekend, Founding Four to First Sixteen.

## 02 · desk-host-b

Four teams walked into arenas that had never hosted a game. McLean looked like a coronation. Miami needed a tiebreaker just to make the playoffs.

## 03 · jack-jet-morrison

And then Neon Reef wrote a different ending. Game Two of the Golden Final — the Miracle Game — aggregate six to five Geckz.

## 04 · coach-chippy

Boys… the energy in that building was nuclear. Third period three unanswered. Overtime triple-deke top shelf. Put that man in jail!

## 05 · veteran-color

McLean played the better hockey for five and a half of six periods. Structure, depth, the Wall Trophy in net. It did not matter. That's PuckGold.

## 06 · desk-host-a

Hardware reminder: PuckGold Cup to Miami. Golden Gecko MVP. Conductor's Crest to Chattanooga — zero wins, everyone's second favorite.

## 07 · desk-host-b

This weekend the ice opens wider. Sixteen teams. Four pools. Fan prizes live. O-G Pass members farm at five-X. Nobody's out until the horn sounds.

## 08 · arena-pa

PuckGold presents Founding Expansion Weekend. Faceoff under the clock. Welcome to the First Sixteen.
