# Backstory · Pre-Game Special

PuckGold Broadcast · Season One download pack

## Contents
- `audio/` — WAV tracks from the Listen player
- `transcripts/` — script JSON + markdown lines

## More marketing / brand
- Brand page: https://roundrobin-v0-02.vercel.app/brand.html
- Full brand kit ZIP: https://roundrobin-v0-02.vercel.app/brand-kit/Downloads/PGB-Brand-Kit.zip
- Logos only: https://roundrobin-v0-02.vercel.app/brand-kit/Downloads/PGB-Logos-Only.zip
- Media resources: https://roundrobin-v0-02.vercel.app/media-resources.html
- Transcripts desk: https://roundrobin-v0-02.vercel.app/transcripts.html
- Listen this show: https://roundrobin-v0-02.vercel.app/listen.html?show=backstory-pregame-miracle

Generated for personal / partner use from the PuckGold vault.
