# Booth Sample Pack · Season One

Slug: 

## 01 · jack-jet-morrison

Live from Neon Reef Stadium — Game Two of the Golden Final! Miami trails on aggregate and needs a big night under the lights.

## 02 · coach-chippy

Boys, the energy in this building is nuclear right now. Miami's flying in warmups — they know it's do-or-die.

## 03 · jack-jet-morrison

Ten seconds! Miami's down one on aggregate — pulls the goalie — puck worked into the slot — SAVED — rebound — GOAL! IT'S TIED! WE'RE HEADED TO OVERTIME!

## 04 · veteran-color

Look at that bench. What a response from Miami.

## 05 · jack-jet-morrison

Overtime underway. Geckz across the blue line — fake shot — the deke — TOP SHELF! THE MIGHTY GECKZ WIN THE PUCKGOLD CUP! FIVE TO FOUR THE FINAL!

## 06 · arena-pa

PuckGold goal, scored by Miami Mighty Geckz! Time of the goal — nineteen fifty-four of the third period!

## 07 · coach-chippy

ARE YOU KIDDING ME?! Put that man in jail — he just stole that goalie's ankles! Roof, water bottle flying — what an absolute beauty!
